package de.ecspride;

public class DataStore {
	public String field;
}
