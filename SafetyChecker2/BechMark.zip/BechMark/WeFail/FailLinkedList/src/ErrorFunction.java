

public class ErrorFunction {
	public static void Error() {

	}
	public static void Error1(int a){
		
	}
	public static void test1(int i) {
		
	}
	public static void Error2(String a){
		
	}
     public static void Error3(boolean a){
		
	}
}
